import random
import configparser

"""通过 配置文件路径 r 文件 将随机的真实ip返回"""
conf_path = '/etc/sns/sns-oracle.conf'
# conf_path = 'config.ini'
real_ip = ''
server_ip = ''
server_port = 0000

try:
    cf = configparser.ConfigParser()
    cf.read(conf_path)  # 文件路径
    b=random.randint(1,5)
    real_ips_str = cf.get("lbserver",'serverip')  # 获取指定section 的option值
    real_ip_list = real_ips_str.split(',')
    real_ip = random.choice(real_ip_list)

    server_ip = cf.get("lbserver",'lbip')
    server_port = int(cf.get("lbserver",'lbport'))
except Exception as e:
    print('【lb-warn】---->读取配置文件时出错！[%s]'%str(e))




