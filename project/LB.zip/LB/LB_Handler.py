# 服务器IP列表
cache_list = []
# 真实服务器IP
resultIP = None

class LB_Service():
    """client user 处理逻辑"""
    def update_data(self, dict_data,request_ip):
        # 1.获取 新的连接数 以便于更新 缓存列表中的 连接数量
        self.updata_num(dict_data,request_ip)
        # 2.取出最小连接数IP
        self.get_real_ip(request_ip)

    def updata_num(self, dict_data,request_ip):
        try:
            # print('[lb-info=%s]---->服务器client更新接收到的数据：%s'%(str(request_ip),str(dict_data)))
            flag = True
            print('[lb-info]服务器client更新前的列表数据：%s'%str(cache_list))
            if len(cache_list) == 0:
                cache_list.append(dict_data)
            else:
                for i in cache_list:
                    # print('i_ip:',i['ip'])
                    if dict_data['ip'] == i['ip']:
                        # print('---[info=%s]---->服务器client此次更新的IP值：%s,连接数旧值：%s，新值：%s'%(str(request_ip),str(cache_list),str(i['connNum']),str(dict_data['connNum'])))
                        if dict_data['connNum']=='' or dict_data['connNum'] is None:
                            cache_list.remove(i)
                        else:
                            i['connNum'] = dict_data['connNum']

                        flag = False
                if flag:
                    if dict_data['connNum'] is not None and dict_data['connNum']!='':
                    # print('---[info=%s]---->服务器client此次缓存列表新增更新值：%s'%(str(request_ip),str(dict_data)))
                        cache_list.append(dict_data)

            print('[lb-info]服务器client更新后的列表数据：%s'%str(cache_list))
        except Exception as e:
            print('【lb-warn】服务器client更新缓存列表出错！[%s]'%str(e))

    #比较连接数，更新/获取真实ip
    def get_real_ip(self,request_ip):
        try:
            if len(cache_list)>0:
                # 2.取出最小连接数IP
                tmp = cache_list[0]['connNum']
                resultIP = cache_list[0]['ip']
                for i in cache_list:
                    a = i['connNum']
                    if int(a) < int(tmp):
                        resultIP = i['ip']
            else:
                resultIP = None
            return resultIP
        except Exception as e:
            print('【lb-warn】更新或获取最小连接数时出错！[%s]'%str(e))

    #user从缓存列表中获取realIP
    def user_getIp(self,request_ip):
        try:
            ip = None
            # 1.先取resultIP值
            if resultIP is not None:
                ip = resultIP
            # 2.若resultIP为None，则cache_list比较连接数取值
            elif len(cache_list) > 0:
                ip = self.get_real_ip(request_ip)
            return ip
        except Exception as e:
            print('【lb-warn】user从缓存数据列表中获取ip时出错！[%s]'%str(e))






# LB_Service()
