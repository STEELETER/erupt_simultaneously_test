import socket,json,threading,struct
from LB_Handler import LB_Service
import LB_Config


#获取服务器本机ip
local_ip = socket.gethostbyname(socket.gethostname())
print( "[lb-info][%s]LB server start..."%str((local_ip,7100)))

#建立lbserver端服务
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('',7100))
s.listen(128)

#线程方法
def threadings(client_socket, request_ip):

    try:
        while True:
            data = client_socket.recv(4096)
            identity_tuple = struct.unpack("i", data[:4]) #buf是从网络接收的字节流
            identity = int(identity_tuple[0])

            service = LB_Service()

            print('<------------------'+str(request_ip)+'-------------------->')
            #客户端连接
            if identity == 868608:
                print("[lb-info]来访身份：user")
                realIp = ''
                try:
                     # 获取缓存列表ip
                    realIp = service.user_getIp(request_ip)
                    print("[lb-info]正常获取的返回值IP：%s" %str(realIp))

                     # 返回服务器本机ip
                    if realIp is None:
                        print("【lb-warn】缓存数据列表空值！返回本机IP：%s" %str(local_ip))
                        realIp = local_ip
                except Exception as e:
                    # 兜底方案：读取配置文件ip，随机抽取返回
                    realIp = LB_Config.real_ip
                    print("【lb-warn】异常配置文件获取的返回值IP：%s,[%s]" %(str(realIp),str(e)))
                finally:
                    server_ip = bytes(realIp,encoding='utf-8')
                    values = (868608,28,12,server_ip,8080)
                    print("[lb-info]发送到客户端的数据：%s" %str(values))

                    #包装为客户端C++可识别的二进制数据
                    result = struct.pack("=i2h16si",*values)
                    client_socket.send(result)
                    client_socket.close()
                    break

            #服务器发送数据：
            else:
                try:
                    print("[lb-info]来访身份：server_client")
                    recv_data_str = data.decode('utf-8')
                    print("[lb-info]接受的数据：%s" %str(recv_data_str))
                    dict_data = json.loads(recv_data_str)
                    service.update_data(dict_data,request_ip)
                except Exception as e:
                    print("【lb-warn】server_client更新出错：[%s]" %str(e))
    except Exception as e:
        print('【lb-warn】接收数据，判断身份时出错![%s]'%str(e))

while True:
    client_socket,addr = s.accept()
    try:
        t = threading.Thread(target=threadings, args=(client_socket,addr))
        t.start()
    except Exception as e:
        print('【lb-warn】连接有误![%s][%s]'%(str(addr),str(e)))











