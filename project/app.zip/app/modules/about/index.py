


def start():
    print("关于启动")