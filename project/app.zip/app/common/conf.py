
#内部系统号
sysnum = 868608

db_path = 'resource/data/db/data.db'

trans_per_size = 10240

updown_serv_addr=('172.21.1.152',7000)

#客户端上传的最多线程数量
up_thread_num=2
#客户端下载的最多线程数量
down_thread_num = 2