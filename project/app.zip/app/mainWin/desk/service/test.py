import time

from modules.manager.py import notify


# notify.add("我附近的司法1")
notify.showAnimation()